﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CountdownHeart1 : MonoBehaviour
{
    float timeleft = 30.0f;
    public GameObject hungerheart;
    
    // Start is called before the first frame update
    void Spawn()
    {
        Instantiate(hungerheart, new Vector2(-385, -256), Quaternion.identity);
    }
    void Hunger()
    {

    }
    SpriteRenderer sprite;
    private void Start()
    {
       Invoke("Spawn", 1);
        CancelInvoke("Spawn");
        GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        if(timeleft < 25 && timeleft > 20)
        {
            sprite.color = new Color(1, 1/2, 1/2, 1);
        }
    }


}
