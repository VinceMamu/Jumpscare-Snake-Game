﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    // Start is called before the first frame update
    public Vector3 myPos;
    public Transform myPlay;
    
    public void Update()
    {
        transform.position = myPlay.position + (myPos);
    }
}
