﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HungerBar : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject hungerbar;
    public GameObject foodPrefab;
    private Rigidbody2D rb;
    private SpriteRenderer sprRend;


    void Awake()
    {
        sprRend = gameObject.AddComponent<SpriteRenderer>() as SpriteRenderer;
        sprRend.drawMode = SpriteDrawMode.Sliced;

        rb = gameObject.AddComponent<Rigidbody2D>() as Rigidbody2D;
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
