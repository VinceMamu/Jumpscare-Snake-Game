﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnFood : MonoBehaviour
{
    public GameObject foodPrefab;
    public GameObject poisonPrefab;
    public Transform bordertop;
    public Transform borderbot;
    public Transform borderleft;
    public Transform borderright;

    void Spawn()
    {
        int x = (int)Random.Range(borderleft.position.x, borderright.position.x);
        int y = (int)Random.Range(bordertop.position.y, borderbot.position.y);

        Instantiate(foodPrefab, new Vector2(x, y), Quaternion.identity);


    }

    void SpawnPoison()
    {
        int a = (int)Random.Range(borderleft.position.x, borderright.position.x);
        int b = (int)Random.Range(bordertop.position.y, borderbot.position.y);

        Instantiate(poisonPrefab, new Vector2(a, b), Quaternion.identity);

    }

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("Spawn", 3, 4);
        InvokeRepeating("SpawnPoison", 5, 4);
    }
}
