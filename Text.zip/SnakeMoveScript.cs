﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.SceneManagement;

public class SnakeMoveScript : MonoBehaviour
{
    List<Transform> tail = new List<Transform>();
    bool ate = false;
    public GameObject tailPrefab;
    public GameObject scaryface;
    public GameObject scarysound;
    Vector2 dir = Vector2.right;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("Move", 0.1f, 0.1f);

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow))
            dir = Vector2.right;
        else if (Input.GetKey(KeyCode.DownArrow))
            dir = -Vector2.up;
        else if (Input.GetKey(KeyCode.UpArrow))
            dir = Vector2.up;
        else if (Input.GetKey(KeyCode.LeftArrow))
            dir = -Vector2.right;
    }

    void Move()
    {
        Vector2 v = transform.position;
        transform.Translate(dir);
        if (ate)
        {
            GameObject g = (GameObject)Instantiate(tailPrefab, v, Quaternion.identity);
            tail.Insert(0, g.transform);
            ate = false;
        }
        else if (tail.Count > 0)
        {
            tail.Last().position = v;

            tail.Insert(0, tail.Last());
            tail.RemoveAt(tail.Count-1);
        }
    }
    void Jumpscare()
    {
        int x = 0;
        int y = 0;
        Instantiate(scaryface, new Vector2(x, y), Quaternion.identity);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.name.StartsWith("FoodPrefab"))
        {
            ate = true;

            Destroy(collision.gameObject);
        }
        if (collision.name.StartsWith("poisonPrefab"))
        {
            Invoke("Jumpscare", 0);
            
            
        }
        if (collision.name.StartsWith("border"))
        {
            SceneManager.LoadScene("SampleScene");
        }
        if (collision.name.StartsWith("tail"))
        {
            SceneManager.LoadScene("SampleScene");

        }
    }
}
